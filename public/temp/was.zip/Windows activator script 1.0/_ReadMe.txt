Instructions:
1) Install windows iso
2) Connect to internet
3) Run as administrator "MAS_1.0_CRC32_1D90323C" and activate your windows
4) Reboot
DONE!
 

You can always thank us here:  www.TheWindowsForum.com /  www.ThumperDC.com